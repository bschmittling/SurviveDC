<?php

/**
 * _______ _     _  ______ _    _ _____ _    _ _______ ______  _______
 * |______ |     | |_____/  \  /    |    \  /  |______ |     \ |      
 * ______| |_____| |    \_   \/   __|__   \/   |______ |_____/ |_____ 
 *
 * CREATED AND DISTRIBUTED BY Cluser Media http://www.cluster-media.com
 *
 * The SurviveDC Manifest iPhone App by Brandon Schmittling is licensed
 * under a Creative Commons Attribution-NonCommercial-ShareAlike 3.0
 * Unported License: http://creativecommons.org/licenses/by-nc-sa/3.0/
 */

?>



<?php

// Application Environment
$applicationURL = "http://projects.cluster-dev.com/journey-app/";
$uploadFolder = "uploaded_files/";

// Database
$dbhost = "db2718.perfora.net";
$dbuser = "dbo350062003";
$dbpass = "j()urn3y-c@tch3$";
$dbname = "db350062003";

// Other
$emailTo = "brandon@cluster-media.com";

?>