<? 
include('mobile-friendly.html');
//This is just a sample file useful for testing _autoregistration.php. I guess we could turn it into an actual registration if we need it
?>

<form action="/" method="POST" enctype="multipart/form-data">
Runner ID: <input name="runner_id" type="text"><br />
Photo: <input name="player_photo" type="file"><br />
<input type="submit" value="Register">

</form>