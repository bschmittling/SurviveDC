<?
include('functions.php');

/*
var_dump($_POST);
var_dump($_GET);

include('functions.php');
print is_valid_runner('RUBIN');

if (function_exists('mysqli')) {
    echo "Yes. mysqli is working<br />\n";
} else {
    echo "No. mysqli isn't working :(<br />\n";
}

if (function_exists('mysqli_connect')) {
    echo "Oh, wait. mysqli is actually working<br />\n";
} else {
    echo "No. mysqli really isn't working :(<br />\n";
}

phpinfo();
*/
?>
<h1>Clear</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fclear" alt="qrcode"  />
<br /><br />

<h1>Registration</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/0" alt="qrcode"  />
<br /><br />

<h1>Checkpoint 1A</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/10" alt="qrcode"  />
<br /><br />

<h1>Checkpoint 1B</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/11" alt="qrcode"  />
<br /><br />

<h1>Checkpoint 2A</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/20" alt="qrcode"  />
<br /><br />


<h1>Checkpoint 2B</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/21" alt="qrcode"  />
<br /><br />

<h1>Checkpoint 3</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/3" alt="qrcode"  />
<br /><br />

<h1>Checkpoint 4</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/4" alt="qrcode"  />
<br /><br />

<h1>Checkpoint 5</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/5" alt="qrcode"  />
<br /><br />

<h1>Checkpoint 6</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/6" alt="qrcode"  />
<br /><br />

<h1>Checkpoint 7</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/7" alt="qrcode"  />
<br /><br />

<h1>Mobile Checkpoint 1</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/100" alt="qrcode"  />
<br /><br />

<h1>Mobile Checkpoint 2</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/101" alt="qrcode"  />
<br /><br />

<h1>Mobile Checkpoint 3</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/102" alt="qrcode"  />
<br /><br />

<h1>Bonus Checkpoint 1</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/200" alt="qrcode"  />
<br /><br />

<h1>Bonus Checkpoint 2</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2Fagent/set/201" alt="qrcode"  />
<br /><br />

<?
$mysql = connectdb(true);
$result = mysql_query("SELECT * FROM ".RUNNERS_TBL." ORDER BY RAND() LIMIT 0,1;");
$row = mysql_fetch_array($result, MYSQL_BOTH);
$rid = $row['runner_id'];

print "<h1>Random User: ".$rid."<h1>";
?>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2F<?= $rid ?>" alt="qrcode"  />
<br /><br />


<h1>T593M</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2FT593M" alt="qrcode"  />
<br /><br />

<h1>E4NPN</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2FE4NPN" alt="qrcode"  />
<br /><br />

<h1>YN9GK</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2FYN9GK" alt="qrcode"  />
<br /><br />

<h1>YNCP7</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2FYNCP7" alt="qrcode"  />
<br /><br />

<h1>A6CTA</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2FA6CTA" alt="qrcode"  />
<br /><br />

<h1>U8QDB</h1>
<img src="http://qrcode.kaywa.com/img.php?s=8&d=http%3A%2F%2Fjl.vc%2FU8QDB" alt="qrcode"  />
<br /><br />