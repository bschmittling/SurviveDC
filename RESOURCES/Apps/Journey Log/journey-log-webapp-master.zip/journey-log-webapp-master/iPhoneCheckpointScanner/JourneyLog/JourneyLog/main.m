//
//  main.m
//  JourneyLog
//
//  Created by Mike Ashmore on 6/11/11.
//  Copyright 2011 Perforce Software. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    int retVal = UIApplicationMain(argc, argv, nil, nil);
    [pool release];
    return retVal;
}
