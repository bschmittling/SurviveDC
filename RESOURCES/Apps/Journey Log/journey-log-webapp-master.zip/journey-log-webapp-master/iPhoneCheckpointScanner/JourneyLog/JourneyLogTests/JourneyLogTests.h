//
//  JourneyLogTests.h
//  JourneyLogTests
//
//  Created by Mike Ashmore on 6/11/11.
//  Copyright 2011 Perforce Software. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface JourneyLogTests : SenTestCase {
@private
    
}

@end
