<!DOCTYPE html>
<html>
<head><script type="text/javascript">var NREUMQ=[];NREUMQ.push(["mark","firstbyte",new Date().getTime()]);</script>
  <title>Journey Log - Journey to the End of the Night - San Francisco - June 2011 - Five Years Running</title>
  <link href="/20110618-sf/cpm/stylesheets/journey.css" rel="stylesheet" type="text/css" />
  <link href="/stylesheets/journey.css?1309163392" media="screen" rel="stylesheet" type="text/css" />
<link href="/stylesheets/scaffold.css?1309030815" media="screen" rel="stylesheet" type="text/css" />
  <script src="/javascripts/prototype.js?1309030814" type="text/javascript"></script>
<script src="/javascripts/effects.js?1309030814" type="text/javascript"></script>

<script src="/javascripts/dragdrop.js?1309030814" type="text/javascript"></script>
<script src="/javascripts/controls.js?1309030814" type="text/javascript"></script>
<script src="/javascripts/rails.js?1309030814" type="text/javascript"></script>
<script src="/javascripts/application.js?1309030814" type="text/javascript"></script>
  <meta name="csrf-param" content="authenticity_token"/>
<meta name="csrf-token" content="3v841JITEpLJ+KC2t0PlZVydOM/b5UYtHUsrn0kC16M="/>
</head>
<body>
		<div class="menu"><a class="menulink" href="/">Journey Log</a> &#8226; <a class="menulink" 
	href="/20110618-sf">Journey to the End of the Night</a> - SF June 2011 &#8226; <a class="menulink" 
	href="/20110618-sf/cpm/runners">Player List</a> &#8226; <a class="menulink" 
	href="/20110618-sf/cpm/runners/chaser_tree">Chaser Tree</a> &#8226; <a class="menulink" 
	href="/20110618-sf/cpm/status">Checkpoints</a> &#8226; <a class="menulink" 
	href="/20110618-sf/_resources/Journey-sf-2011-manifest.pdf">Manifest</a> &#8226; <a class="menulink" href="http://5yearsrunning.com">Five Years Running</a> &#8226; <a class="menulink" href="http://totheendofthenight.com">To the End of the Night</a> &#8226; <a class="menulink" href="http://sf0.org/tasks/Journey-to-the-End-of-the-Night-Five-Years-Running-in-SF/">SF&Oslash;</a></div>

	<div class="content">
		<img style="position: relative; top: 0px; left: 50%; height: 350px; width: 600px; margin: 0 0 0 -300px; padding: 5px;" src="_resources/5yearsrunning-blogposter1.jpg">
			
				<br><a href="http://creativecommons.org/licenses/by-nc/3.0/"><img style="float:right;" src="http://5yearsrunning.com/images/creativecommons.png"></a>
			</div>
		<script type="text/javascript">

		  var _gaq = _gaq || [];
		  _gaq.push(['_setAccount', 'UA-24017607-1']);
		  _gaq.push(['_trackPageview']);

		  (function() {
		    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
		    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		  })();

		</script>
		<script type="text/javascript">(function(){var d=document;var e=d.createElement("script");e.async=true;e.src="https://d1ros97qkrwjf5.cloudfront.net/14/eum/rum.js	";e.type="text/javascript";var s=d.getElementsByTagName("script")[0];s.parentNode.insertBefore(e,s);})();NREUMQ.push(["nrf2","beacon-1.newrelic.com","1d3e4f046e",136952,"dFwIFkpXWw0ESxgXQVldAxBLF0QJDk4=",0,327,new Date().getTime()])</script></body>
		</html>
