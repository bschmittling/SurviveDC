# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '195129bf857f30f86dd5a1a621fc0d55d48594dc13092e500ea30e35e694f8bbe10a2c86150cdee5bef7ec17f9f725e62f793b91132f1bc552a0c8c55690f616';
