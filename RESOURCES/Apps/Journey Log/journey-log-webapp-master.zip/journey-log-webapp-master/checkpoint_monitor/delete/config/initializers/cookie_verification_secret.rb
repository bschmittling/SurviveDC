# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '9e61f269c9289100a730bfae977d4122d999ae9679586c0f045d812162deff92a213087b893a3e1c8670f8bb80d234c54c5310ff60287b6019e329dfff3cb026';
