require 'test_helper'

class CatchesHelperTest < ActionView::TestCase
end
