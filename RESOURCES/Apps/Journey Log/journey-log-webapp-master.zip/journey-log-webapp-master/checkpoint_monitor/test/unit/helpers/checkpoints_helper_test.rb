require 'test_helper'

class CheckpointsHelperTest < ActionView::TestCase
end
