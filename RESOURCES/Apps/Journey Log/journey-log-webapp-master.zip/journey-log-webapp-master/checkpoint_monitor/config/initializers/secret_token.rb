# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
SurvivedcOrg::Application.config.secret_token = '52284bd292497143e512f2a3f1f1904caf51e704a57a51a0d8cd69b31e7bce4382785f3c1f2919f2500363abca770f4b34a88a223b2b58f5813d25c2a0e207de'
