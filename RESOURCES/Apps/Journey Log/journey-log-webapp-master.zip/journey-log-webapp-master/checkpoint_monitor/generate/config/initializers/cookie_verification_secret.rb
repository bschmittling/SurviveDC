# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '15bb5e45526ff4766e58e831f906a782520716f04b667b33234b1bf21e820fcb27494f63a2f7d54517ed6784983595ef88873f4b34a0ebaef928ad953cd557e0';
